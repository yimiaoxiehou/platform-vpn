//go:build !linux && !windows && !darwin

package pmtud_fix

const (
	DisablePathMTUDiscovery = true
)
